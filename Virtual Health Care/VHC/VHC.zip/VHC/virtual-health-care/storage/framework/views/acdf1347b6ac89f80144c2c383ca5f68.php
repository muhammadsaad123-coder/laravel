<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1><?php echo e($service->name); ?></h1>
    <p><?php echo e($service->description); ?></p>
    <a href="<?php echo e(route('services.index')); ?>" class="btn btn-primary">Back to Services</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VHC\virtual-health-care\resources\views/services/show.blade.php ENDPATH**/ ?>