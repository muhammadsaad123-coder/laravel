<?php $__env->startSection('content'); ?>
<div class="container mt-5">
    <h1>Services</h1>
    <a href="<?php echo e(route('services.create')); ?>" class="btn btn-primary mb-3">Create New Service</a>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <table class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($service->name); ?></td>
                    <td><?php echo e($service->description); ?></td>
                    <td>
                        <a href="<?php echo e(route('services.show', $service->id)); ?>" class="btn btn-info">View</a>
                        <a href="<?php echo e(route('services.edit', $service->id)); ?>" class="btn btn-warning">Edit</a>
                        <form action="<?php echo e(route('services.destroy', $service->id)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\VHC\virtual-health-care\resources\views/services/index.blade.php ENDPATH**/ ?>